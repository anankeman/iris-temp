package pb.protocols;

public interface ICallback {
	public void callback();
}
