package pb;

@SuppressWarnings("serial")
public class ProtocolAlreadyRunning extends Exception {

}
