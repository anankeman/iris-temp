package pb;

@SuppressWarnings("serial")
public class EndpointUnavailable extends Exception {

}
